﻿using System;
using System.IO;
using System.Linq;
using Microsoft.ML;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace KEDBTool.V1._0
{
    class Program
    {
        private static string _appPath => Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]);

        //private static string _trainDataPath => Path.Combine(_appPath, "..", "..", "..", "Data", "issues_train.tsv");

        private static string _trainDataPathClus => Path.Combine(Environment.CurrentDirectory, "Data", "issues_train_cluster.tsv");
        private static string _trainDataPath => Path.Combine(Environment.CurrentDirectory, "Data", "issues_train.tsv");
        private static string _trainDataPathRec => Path.Combine(Environment.CurrentDirectory, "Data", "Recommend.csv");
        private static string _testDataPath => Path.Combine(_appPath, "..", "..", "..", "Data", "issues_test.tsv");

        static readonly string _dataPathProac = Path.Combine(Environment.CurrentDirectory, "Data", "IssueOccurence.csv");
        private static string _modelPath => Path.Combine(_appPath, "..", "..", "..", "Models", "model.zip");
        private static string _modelPathRec => Path.Combine(_appPath, "..", "..", "..", "Models", "modelrec.zip");

        private static string _clusterModelPath = Path.Combine(Environment.CurrentDirectory, "Models", "ClusteringModel.zip");

        private static IssueCollection _issueCollection = new IssueCollection() { IssueList = new List<string>() };

        private static MLContext _mlContext;
        private static PredictionEngine<CherwellIssue, IssuePrediction> _predEngine;
        private static PredictionEngine<FfmRecommendationData, FfmRecommendationPrediction> _predictionEngineRec;
        private static ITransformer _trainedModel;
        static IDataView _trainingDataView;

        const int _docsize = 36;

        static void Main(string[] args)
        {
            //module - clustering issues
            ClusterIssues();

            //Begin the Ml context
            _mlContext = new MLContext(seed: 0);

            //Load issue details
            _trainingDataView = _mlContext.Data.LoadFromTextFile<CherwellIssue>(_trainDataPath, hasHeader: true);

            var pipeline = ProcessData();

            var trainingPipeline = BuildAndTrainModel(_trainingDataView, pipeline);

            Evaluate(_trainingDataView.Schema);

            PredictIssue();

            //Recommendations
            RecommendResolution();

            //Proactive Maintenance
            ProactiveIssueDetection();
        }

        public static IEstimator<ITransformer> BuildAndTrainModel(IDataView trainingDataView, IEstimator<ITransformer> pipeline)
        {
            var trainingPipeline = pipeline.Append(_mlContext.MulticlassClassification.Trainers.SdcaMaximumEntropy("Label", "Features"))
            .Append(_mlContext.Transforms.Conversion.MapKeyToValue("PredictedLabel"));

            _trainedModel = trainingPipeline.Fit(trainingDataView);

            _predEngine = _mlContext.Model.CreatePredictionEngine<CherwellIssue, IssuePrediction>(_trainedModel);

            return trainingPipeline;
        }

        public static void Evaluate(DataViewSchema trainingDataViewSchema)
        {
            var testDataView = _mlContext.Data.LoadFromTextFile<CherwellIssue>(_testDataPath, hasHeader: true);

            var testMetrics = _mlContext.MulticlassClassification.Evaluate(_trainedModel.Transform(testDataView));

            //Console.WriteLine($"*************************************************************************************************************");
            //Console.WriteLine($"*       Metrics for Multi-class Classification model - Test Data     ");
            //Console.WriteLine($"*------------------------------------------------------------------------------------------------------------");
            //Console.WriteLine($"*       MicroAccuracy:    {testMetrics.MicroAccuracy:0.###}");
            //Console.WriteLine($"*       MacroAccuracy:    {testMetrics.MacroAccuracy:0.###}");
            //Console.WriteLine($"*       LogLoss:          {testMetrics.LogLoss:#.###}");
            //Console.WriteLine($"*       LogLossReduction: {testMetrics.LogLossReduction:#.###}");
            //Console.WriteLine($"*************************************************************************************************************");

            SaveModelAsFile(_mlContext, trainingDataViewSchema, _trainedModel);
        }

        private static void SaveModelAsFile(MLContext mlContext, DataViewSchema trainingDataViewSchema, ITransformer model)
        {
            mlContext.Model.Save(model, trainingDataViewSchema, _modelPath);
        }
        public static IEstimator<ITransformer> ProcessData()
        {
            var pipeline = _mlContext.Transforms.Conversion.MapValueToKey(inputColumnName: "Area", outputColumnName: "Label")
                .Append(_mlContext.Transforms.Text.FeaturizeText(inputColumnName: "Title", outputColumnName: "TitleFeaturized"))
                .Append(_mlContext.Transforms.Text.FeaturizeText(inputColumnName: "Description", outputColumnName: "DescriptionFeaturized"))
                .Append(_mlContext.Transforms.Concatenate("Features", "TitleFeaturized", "DescriptionFeaturized"))
                .AppendCacheCheckpoint(_mlContext);

            return pipeline;
        }

        private static void PredictIssue()
        {
            ITransformer loadedModel = _mlContext.Model.Load(_modelPath, out var modelInputSchema);

            CherwellIssue singleIssue = new CherwellIssue(); // { Title = "Entity Framework crashes", Description = "When connecting to the database, EF is crashing" };

            Console.WriteLine("Predicitng single issue... Enter Issue details.");

            Console.WriteLine("Enter Title:");

            singleIssue.Title = Console.ReadLine();


            Console.WriteLine("Enter Description:");

            singleIssue.Description = Console.ReadLine();

            _predEngine = _mlContext.Model.CreatePredictionEngine<CherwellIssue, IssuePrediction>(loadedModel);

            var prediction = _predEngine.Predict(singleIssue);

            Console.WriteLine($"=============== Single Prediction - Results being stored ===============");

            using (SqlConnection connection = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=hackthon;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
            {
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandType = CommandType.Text;
                    command.CommandText = "INSERT into IssueClassification (Area, IssueTitle, IssueDescription) VALUES (@area, @issuetitle, @issuedescription)";
                    command.Parameters.AddWithValue("@area", prediction.Area);
                    command.Parameters.AddWithValue("@issuetitle", singleIssue.Title);
                    command.Parameters.AddWithValue("@issuedescription", singleIssue.Description);

                    try
                    {
                        connection.Open();
                        int recordsAffected = command.ExecuteNonQuery();
                    }
                    catch (SqlException ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
            }

        public static void ClusterIssues()
        {
            //initializing dummy data
            int i = 0;
            var lines = File.ReadAllLines(_trainDataPathClus).Select(x => x.Split('\t'));

            int lineLength = lines.First().Count();
            var CSV = lines.Skip(1)
                       .Select(x => x);

            foreach (var data in CSV)
            {
                _issueCollection.IssueList.Add(data[2] + " " + data[3]);
            }

            List<TextVector> vSpace = VectorSpaceModel.ProcessDocumentCollection(_issueCollection);
            int totalIteration = 0;
            List<Centroid> resultSet = TextClustering.PrepareTextCluster(int.Parse(ConfigurationManager.AppSettings["ClusterCount"]), vSpace, ref totalIteration);

            foreach (Centroid c in resultSet)
            {
                Console.WriteLine("------------------------------Cluster[" + i.ToString() + "] is getting written to database------------------------", i);

                using (SqlConnection connection = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=hackthon;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
                {
                    foreach (TextVector v in c.GroupedText)
                    {
                        using (SqlCommand command = new SqlCommand())
                        {
                            command.Connection = connection;            
                            command.CommandType = CommandType.Text;
                            command.CommandText = "INSERT into ClusteredIssues (Cluster, Issue) VALUES (@cluster, @issue)";
                            command.Parameters.AddWithValue("@cluster", "Cluster[" + i.ToString() + "]");
                            command.Parameters.AddWithValue("@issue", v.Content.ToString());

                            try
                            {
                                connection.Open();
                                int recordsAffected = command.ExecuteNonQuery();
                            }
                            catch (SqlException ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            finally
                            {
                                connection.Close();
                            }
                        }
                    }
                }       
                i++;
            }
        }

        public static void RecommendResolution()
        {
            var data = File.ReadAllLines(_trainDataPathRec)
       .Skip(1)
       .Select(x => x.Split(','))
       .Select(x => new FfmRecommendationData
       {
           Label = Convert.ToBoolean(x[0]),
           Application = x[1],
           CauseCode = x[2],
           ResolutionCode = x[3]
       });

            _trainingDataView = _mlContext.Data.LoadFromEnumerable(data);

            var pipeline = _mlContext.Transforms.Categorical.OneHotEncoding("ApplicationTypeOneHot", "Application")
    .Append(_mlContext.Transforms.Categorical.OneHotEncoding("CauseCodeOneHot", "CauseCode"))
    .Append(_mlContext.Transforms.Categorical.OneHotEncoding("ResolutionCodeOneHot", "ResolutionCode"))
    .Append(_mlContext.Transforms.Concatenate("Features", "ApplicationTypeOneHot", "CauseCodeOneHot", "ResolutionCodeOneHot"))
    .Append(_mlContext.BinaryClassification.Trainers.FieldAwareFactorizationMachine(new string[] { "Features" }));

            _trainedModel = pipeline.Fit(_trainingDataView);
            _predictionEngineRec = _mlContext.Model.CreatePredictionEngine<FfmRecommendationData, FfmRecommendationPrediction>(_trainedModel);

            _mlContext.Model.Save(_trainedModel, _trainingDataView.Schema, _modelPathRec);

            var ResArr = new List<string> ();

            Console.WriteLine($"=============== Recommendation based on Application and Cause Code ===============");

            ///predict single issue
            FfmRecommendationData singleIssue = new FfmRecommendationData();

            Console.WriteLine("Enter Application");

            singleIssue.Application = Console.ReadLine();

            Console.WriteLine("Enter Cause Code");

            singleIssue.CauseCode = Console.ReadLine();

            foreach (FfmRecommendationData issue in data)
            {
                if (!ResArr.Contains(issue.ResolutionCode))
                {
                    singleIssue.ResolutionCode = issue.ResolutionCode;

                    ResArr.Add(issue.ResolutionCode);

                    var prediction = _predictionEngineRec.Predict(singleIssue);

                    if (!prediction.PredictedLabel)
                    {
                        // Bring to a range from -1 (highly discouraged) to +1 (highly recommended).
                        prediction.Probability = -prediction.Probability;
                    }

                    
                    using (SqlConnection connection = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=hackthon;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
                    {
                        using (SqlCommand command = new SqlCommand())
                        {
                            command.Connection = connection;
                            command.CommandType = CommandType.Text;
                            command.CommandText = "INSERT into IssueRecommendation (App, Cause_Code, Resolution_Code, Proability) VALUES (@app, @causecode, @resolutioncode,@proability)";
                            command.Parameters.AddWithValue("@app", singleIssue.Application);
                            command.Parameters.AddWithValue("@causecode", singleIssue.CauseCode);
                            command.Parameters.AddWithValue("@resolutioncode", singleIssue.ResolutionCode);
                            command.Parameters.AddWithValue("@proability", prediction.Probability);

                            try
                            {
                                connection.Open();
                                int recordsAffected = command.ExecuteNonQuery();
                            }
                            catch (SqlException ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            finally
                            {
                                connection.Close();
                            }
                        }
                    }

                    Console.WriteLine($"=============== Recommendation based on Application and Cause Code being stored into database ===============");
                }
            }

            // Group prediction
            var testData = _mlContext.Data.ShuffleRows(_trainingDataView);

            var scoredData = _trainedModel.Transform(testData);
            var metrics = _mlContext.BinaryClassification.Evaluate(
                data: scoredData,
                labelColumnName: "Label",
                scoreColumnName: "Probability",
                predictedLabelColumnName: "PredictedLabel");

            Console.ReadKey();
        }

        public static void ProactiveIssueDetection()
        {
            _trainingDataView = _mlContext.Data.LoadFromTextFile<IssueOccurenceData>(path: _dataPathProac, hasHeader: true, separatorChar: ',');

            DetectSpike(_mlContext, _docsize, _trainingDataView);
            DetectChangepoint(_mlContext, _docsize, _trainingDataView);
        }

        static IDataView CreateEmptyDataView(MLContext mlContext)
        {
            // Create empty DataView. We just need the schema to call Fit() for the time series transforms
            IEnumerable<IssueOccurenceData> enumerableData = new List<IssueOccurenceData>();
            return mlContext.Data.LoadFromEnumerable(enumerableData);
        }

        static void DetectSpike(MLContext mlContext, int docSize, IDataView issueOccurence)
        {
            var iidSpikeEstimator = mlContext.Transforms.DetectIidSpike(outputColumnName: nameof(IssueOccurencePrediction.Prediction), inputColumnName: nameof(IssueOccurenceData.IssueOccurence), confidence: 95, pvalueHistoryLength: docSize / 4);

            ITransformer iidSpikeTransform = iidSpikeEstimator.Fit(CreateEmptyDataView(mlContext));

            IDataView transformedData = iidSpikeTransform.Transform(issueOccurence);

            var predictions = mlContext.Data.CreateEnumerable<IssueOccurencePrediction>(transformedData, reuseRowObject: false);

            Console.WriteLine("Detected Spike recorded into database...");

            foreach (var p in predictions)
            {
                


                using (SqlConnection connection = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=hackthon;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
                {
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = connection;
                        command.CommandType = CommandType.Text;
                        command.CommandText = "INSERT into IssueSpike (Alert, Score, PVlue) VALUES (@alert, @score, @pvlue)";
                        command.Parameters.AddWithValue("@alert", p.Prediction[0]);
                        command.Parameters.AddWithValue("@score", p.Prediction[1]);
                        command.Parameters.AddWithValue("@pvlue", p.Prediction[2]);

                        try
                        {
                            connection.Open();
                            int recordsAffected = command.ExecuteNonQuery();
                        }
                        catch (SqlException ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        finally
                        {
                            connection.Close();
                        }
                    }

                }
            }
            Console.WriteLine("");
        }

        static void DetectChangepoint(MLContext mlContext, int docSize, IDataView issueOccurence)
        {
            var iidChangePointEstimator = mlContext.Transforms.DetectIidChangePoint(outputColumnName: nameof(IssueOccurencePrediction.Prediction), inputColumnName: nameof(IssueOccurenceData.IssueOccurence), confidence: 95, changeHistoryLength: docSize / 4);

            var iidChangePointTransform = iidChangePointEstimator.Fit(CreateEmptyDataView(mlContext));

            IDataView transformedData = iidChangePointTransform.Transform(issueOccurence);

            var predictions = mlContext.Data.CreateEnumerable<IssueOccurencePrediction>(transformedData, reuseRowObject: false);

            Console.WriteLine("Detected Change point recorded into database...");

            foreach (var p in predictions)
            {
                using (SqlConnection connection = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=hackthon;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
                {
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = connection;
                        command.CommandType = CommandType.Text;
                        command.CommandText = "INSERT into IssueSpike (Alert, Score, PVlue, MVlue) VALUES (@alert, @score, @pvlue, @mvlue)";
                        command.Parameters.AddWithValue("@alert", p.Prediction[0]);
                        command.Parameters.AddWithValue("@score", p.Prediction[1]);
                        command.Parameters.AddWithValue("@pvlue", p.Prediction[2]);
                        command.Parameters.AddWithValue("@mvlue", p.Prediction[3]);

                        try
                        {
                            connection.Open();
                            int recordsAffected = command.ExecuteNonQuery();
                        }
                        catch (SqlException ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        finally
                        {
                            connection.Close();
                        }
                    }

                }
            }
            Console.WriteLine("");
        }
    }
}
