﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace KEDBTool.V1._0
{
    /// <summary>
    /// To remove frequently used words in an issue
    /// </summary>
    class StopWordsHandler
    {
        //you can defined other stop word list here
        public static string[] stopWordsList = new string[] { "The" };

        public static Boolean IsStotpWord(string word)
        {
            if (stopWordsList.Contains(word))
                return true;
            else
                return false;
        }
    }
}
