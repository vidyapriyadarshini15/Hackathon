﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KEDBTool.V1._0
{
    /// <summary>
    /// It reporesents a collection of Issues
    /// </summary>
    class IssueCollection
    {
        public List<String> IssueList { get; set; }
        
    }
}
