﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KEDBTool.V1._0
{
    class TextClustering
    {
        private static int globalCounter = 0;
        private static int counter;

        public static List<Centroid> PrepareTextCluster(int k, List<TextVector> documentCollection, ref int _counter)
        {
            globalCounter = 0;
            //prepares k initial centroid and assign one object randomly to each centroid
            List<Centroid> centroidCollection = new List<Centroid>();
            Centroid c;

            /*
             * Avoid repeation of random number, if same no is generated more than once same document is added to the next cluster 
             * so avoid it using HasSet collection
             */
            HashSet<int> uniqRand = new HashSet<int>();
            GenerateRandomNumber(ref uniqRand, k, documentCollection.Count);

            foreach (int pos in uniqRand)
            {
                c = new Centroid();
                c.GroupedText = new List<TextVector>();
                c.GroupedText.Add(documentCollection[pos]);
                centroidCollection.Add(c);
            }

            Boolean stoppingCriteria;
            List<Centroid> resultSet;
            List<Centroid> prevClusterCenter;

            InitializeClusterCentroid(out resultSet, centroidCollection.Count);

            do
            {
                prevClusterCenter = centroidCollection;

                foreach (TextVector obj in documentCollection)
                {
                    int index = FindClosestClusterCenter(centroidCollection, obj);
                    resultSet[index].GroupedText.Add(obj);
                }
                InitializeClusterCentroid(out centroidCollection, centroidCollection.Count());
                centroidCollection = CalculateMeanPoints(resultSet);
                stoppingCriteria = CheckStoppingCriteria(prevClusterCenter, centroidCollection);
                if (!stoppingCriteria)
                {
                    //initialize the result set for next iteration
                    InitializeClusterCentroid(out resultSet, centroidCollection.Count);
                }


            } while (stoppingCriteria == false);

            _counter = counter;
            return resultSet;

        }

        private static void GenerateRandomNumber(ref HashSet<int> uniqRand, int k, int txtCount)
        {

            Random r = new Random();

            if (k > txtCount)
            {
                do
                {
                    int pos = r.Next(0, txtCount);
                    uniqRand.Add(pos);

                } while (uniqRand.Count != txtCount);
            }
            else
            {
                do
                {
                    int pos = r.Next(0, txtCount);
                    uniqRand.Add(pos);

                } while (uniqRand.Count != k);
            }
        }

        /// <summary>
        /// Initialize the result cluster centroid for the next iteration, that holds the result to be returned
        /// </summary>
        /// <param name="centroid"></param>
        /// <param name="count"></param>
        private static void InitializeClusterCentroid(out List<Centroid> centroid, int count)
        {
            Centroid c;
            centroid = new List<Centroid>();
            for (int i = 0; i < count; i++)
            {
                c = new Centroid();
                c.GroupedText = new List<TextVector>();
                centroid.Add(c);
            }

        }

        //returns index of closest cluster centroid
        private static int FindClosestClusterCenter(List<Centroid> clusterCenter, TextVector obj)
        {

            float[] similarityMeasure = new float[clusterCenter.Count()];

            for (int i = 0; i < clusterCenter.Count(); i++)
            {

                similarityMeasure[i] = SimilarityMetrics.FindCosineSimilarity(clusterCenter[i].GroupedText[0].VectorSpace, obj.VectorSpace);

            }

            int index = 0;
            float maxValue = similarityMeasure[0];
            for (int i = 0; i < similarityMeasure.Count(); i++)
            {
                //if document is similar assign the document to the lowest index cluster center to avoid the long loop
                if (similarityMeasure[i] > maxValue)
                {
                    maxValue = similarityMeasure[i];
                    index = i;

                }
            }
            return index;

        }


        //Reposition the centroid
        private static List<Centroid> CalculateMeanPoints(List<Centroid> _clusterCenter)
        {

            for (int i = 0; i < _clusterCenter.Count(); i++)
            {

                if (_clusterCenter[i].GroupedText.Count() > 0)
                {

                    for (int j = 0; j < _clusterCenter[i].GroupedText[0].VectorSpace.Count(); j++)
                    {
                        float total = 0;

                        foreach (TextVector vSpace in _clusterCenter[i].GroupedText)
                        {

                            total += vSpace.VectorSpace[j];

                        }

                        //reassign new calculated mean on each cluster center, It indicates the reposition of centroid
                        _clusterCenter[i].GroupedText[0].VectorSpace[j] = total / _clusterCenter[i].GroupedText.Count();

                    }

                }

            }

            return _clusterCenter;

        }

        /// <summary>
        /// Check the stopping criteria for the iteration, if centroid do not move their position it meets the criteria
        /// or if the global counter exist its predefined limit(minimum iteration threshold) than iteration terminates
        /// </summary>
        /// <param name="prevClusterCenter"></param>
        /// <param name="newClusterCenter"></param>
        /// <returns></returns>
        private static Boolean CheckStoppingCriteria(List<Centroid> prevClusterCenter, List<Centroid> newClusterCenter)
        {

            globalCounter++;
            counter = globalCounter;
            if (globalCounter > 11000)
            {
                return true;
            }

            else
            {
                Boolean stoppingCriteria;
                int[] changeIndex = new int[newClusterCenter.Count()]; //1 = centroid has moved 0 == centroid do not moved its position

                int index = 0;
                do
                {
                    int count = 0;
                    if (newClusterCenter[index].GroupedText.Count == 0 && prevClusterCenter[index].GroupedText.Count == 0)
                    {
                        index++;
                    }
                    else if (newClusterCenter[index].GroupedText.Count != 0 && prevClusterCenter[index].GroupedText.Count != 0)
                    {
                        for (int j = 0; j < newClusterCenter[index].GroupedText[0].VectorSpace.Count(); j++)
                        {
                            //
                            if (newClusterCenter[index].GroupedText[0].VectorSpace[j] == prevClusterCenter[index].GroupedText[0].VectorSpace[j])
                            {
                                count++;
                            }

                        }

                        if (count == newClusterCenter[index].GroupedText[0].VectorSpace.Count())
                        {
                            changeIndex[index] = 0;
                        }
                        else
                        {
                            changeIndex[index] = 1;
                        }
                        index++;
                    }
                    else
                    {
                        index++;
                        continue;

                    }


                } while (index < newClusterCenter.Count());

                // if index list contains 1 stopping criteria is set to flase
                if (changeIndex.Where(s => (s != 0)).Select(r => r).Any())
                {
                    stoppingCriteria = false;
                }
                else
                    stoppingCriteria = true;

                return stoppingCriteria;
            }


        }
    }
}
