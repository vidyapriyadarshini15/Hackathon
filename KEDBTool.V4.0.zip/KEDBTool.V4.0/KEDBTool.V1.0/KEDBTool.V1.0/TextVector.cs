﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KEDBTool.V1._0
{
    class TextVector
    {
        //Content represents the text(or any other object) to be clustered
        public string Content { get; set; }
        //represents the tf*idf of  each text
        public float[] VectorSpace { get; set; }
    }
}
