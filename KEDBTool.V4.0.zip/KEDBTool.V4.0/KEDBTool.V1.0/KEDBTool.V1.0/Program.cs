﻿using System;
using System.IO;
using System.Linq;
using Microsoft.ML;
using System.Collections.Generic;

namespace KEDBTool.V1._0
{
    class Program
    {
        private static string _appPath => Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]);

        //private static string _trainDataPath => Path.Combine(_appPath, "..", "..", "..", "Data", "issues_train.tsv");

        private static string _trainDataPath => Path.Combine(Environment.CurrentDirectory, "Data", "issues_train.tsv");
        private static string _trainDataPathRec => Path.Combine(Environment.CurrentDirectory, "Data", "Recommend.csv");
        private static string _testDataPath => Path.Combine(_appPath, "..", "..", "..", "Data", "issues_test.tsv");

        static readonly string _dataPathProac = Path.Combine(Environment.CurrentDirectory, "Data", "IssueOccurence.csv");
        private static string _modelPath => Path.Combine(_appPath, "..", "..", "..", "Models", "model.zip");
        private static string _modelPathRec => Path.Combine(_appPath, "..", "..", "..", "Models", "modelrec.zip");

        private static string _clusterModelPath = Path.Combine(Environment.CurrentDirectory, "Models", "ClusteringModel.zip");

        private static IssueCollection _issueCollection = new IssueCollection() { IssueList = new List<string>() };

        private static MLContext _mlContext;
        private static PredictionEngine<CherwellIssue, IssuePrediction> _predEngine;
        private static PredictionEngine<FfmRecommendationData, FfmRecommendationPrediction> _predictionEngineRec;
        private static ITransformer _trainedModel;
        static IDataView _trainingDataView;

        const int _docsize = 36;

        static void Main(string[] args)
        {
            //module - clustering issues
            //ClusterIssues();

            ////Begin the Ml context
            _mlContext = new MLContext(seed: 0);

            ////Load issue details
            //_trainingDataView = _mlContext.Data.LoadFromTextFile<CherwellIssue>(_trainDataPath, hasHeader: true);

            //var pipeline = ProcessData();

            //var trainingPipeline = BuildAndTrainModel(_trainingDataView, pipeline);

            //Evaluate(_trainingDataView.Schema);

            //PredictIssue();

            //Recommendations
            RecommendResolution();

            //Proactive Maintenance
            //ProactiveIssueDetection();
        }

        public static IEstimator<ITransformer> BuildAndTrainModel(IDataView trainingDataView, IEstimator<ITransformer> pipeline)
        {
            var trainingPipeline = pipeline.Append(_mlContext.MulticlassClassification.Trainers.SdcaMaximumEntropy("Label", "Features"))
            .Append(_mlContext.Transforms.Conversion.MapKeyToValue("PredictedLabel"));

            _trainedModel = trainingPipeline.Fit(trainingDataView);

            _predEngine = _mlContext.Model.CreatePredictionEngine<CherwellIssue, IssuePrediction>(_trainedModel);

            CherwellIssue issue = new CherwellIssue()
            {
                Title = "WebSockets communication is slow in my machine",
                Description = "The WebSockets communication used under the covers by SignalR looks like is going slow in my development machine.."
            };

            var prediction = _predEngine.Predict(issue);

            Console.WriteLine($"=============== Single Prediction just-trained-model - Result: {prediction.Area} ===============");

            return trainingPipeline;
        }

        public static void Evaluate(DataViewSchema trainingDataViewSchema)
        {
            var testDataView = _mlContext.Data.LoadFromTextFile<CherwellIssue>(_testDataPath, hasHeader: true);

            var testMetrics = _mlContext.MulticlassClassification.Evaluate(_trainedModel.Transform(testDataView));

            Console.WriteLine($"*************************************************************************************************************");
            Console.WriteLine($"*       Metrics for Multi-class Classification model - Test Data     ");
            Console.WriteLine($"*------------------------------------------------------------------------------------------------------------");
            Console.WriteLine($"*       MicroAccuracy:    {testMetrics.MicroAccuracy:0.###}");
            Console.WriteLine($"*       MacroAccuracy:    {testMetrics.MacroAccuracy:0.###}");
            Console.WriteLine($"*       LogLoss:          {testMetrics.LogLoss:#.###}");
            Console.WriteLine($"*       LogLossReduction: {testMetrics.LogLossReduction:#.###}");
            Console.WriteLine($"*************************************************************************************************************");

            SaveModelAsFile(_mlContext, trainingDataViewSchema, _trainedModel);
        }

        private static void SaveModelAsFile(MLContext mlContext, DataViewSchema trainingDataViewSchema, ITransformer model)
        {
            mlContext.Model.Save(model, trainingDataViewSchema, _modelPath);
        }
        public static IEstimator<ITransformer> ProcessData()
        {
            var pipeline = _mlContext.Transforms.Conversion.MapValueToKey(inputColumnName: "Area", outputColumnName: "Label")
                .Append(_mlContext.Transforms.Text.FeaturizeText(inputColumnName: "Title", outputColumnName: "TitleFeaturized"))
                .Append(_mlContext.Transforms.Text.FeaturizeText(inputColumnName: "Description", outputColumnName: "DescriptionFeaturized"))
                .Append(_mlContext.Transforms.Concatenate("Features", "TitleFeaturized", "DescriptionFeaturized"))
                .AppendCacheCheckpoint(_mlContext);

            return pipeline;
        }

        private static void PredictIssue()
        {
            ITransformer loadedModel = _mlContext.Model.Load(_modelPath, out var modelInputSchema);

            CherwellIssue singleIssue = new CherwellIssue() { Title = "Entity Framework crashes", Description = "When connecting to the database, EF is crashing" };

            _predEngine = _mlContext.Model.CreatePredictionEngine<CherwellIssue, IssuePrediction>(loadedModel);

            var prediction = _predEngine.Predict(singleIssue);

            Console.WriteLine($"=============== Single Prediction - Result: {prediction.Area} ===============");
        }

        public static void ClusterIssues()
        {
            //initializing dummy data
            
            var lines = File.ReadAllLines(_trainDataPath).Select(x => x.Split('\t'));

            int lineLength = lines.First().Count();
            var CSV = lines.Skip(1)
                       //.SelectMany(x => x)
                       //.Select((v, i) => new { Value = v, Index = i % lineLength })
                       //.Where(x => x.Index == 2 || x.Index == 3)
                       .Select(x => x);

            foreach (var data in CSV)
            {
                _issueCollection.IssueList.Add(data[2] + " " + data[3]);
            }

            List<TextVector> vSpace = VectorSpaceModel.ProcessDocumentCollection(_issueCollection);
            int totalIteration = 0;
            List<Centroid> resultSet = TextClustering.PrepareTextCluster(int.Parse("3"), vSpace, ref totalIteration);
            
        }

        public static void RecommendResolution()
        {
            var data = File.ReadAllLines(_trainDataPathRec)
       .Skip(1)
       .Select(x => x.Split(','))
       .Select(x => new FfmRecommendationData
       {
           Label = Convert.ToBoolean(x[0]),
           Application = x[1],
           CauseCode = x[2],
           ResolutionCode = x[3]
       });

            _trainingDataView = _mlContext.Data.LoadFromEnumerable(data);

            var pipeline = _mlContext.Transforms.Categorical.OneHotEncoding("ApplicationTypeOneHot", "Application")
    .Append(_mlContext.Transforms.Categorical.OneHotEncoding("CauseCodeOneHot", "CauseCode"))
    .Append(_mlContext.Transforms.Categorical.OneHotEncoding("ResolutionCodeOneHot", "ResolutionCode"))
    .Append(_mlContext.Transforms.Concatenate("Features", "ApplicationTypeOneHot", "CauseCodeOneHot", "ResolutionCodeOneHot"))
    .Append(_mlContext.BinaryClassification.Trainers.FieldAwareFactorizationMachine(new string[] { "Features" }));

            _trainedModel = pipeline.Fit(_trainingDataView);
            _predictionEngineRec = _mlContext.Model.CreatePredictionEngine<FfmRecommendationData, FfmRecommendationPrediction>(_trainedModel);

            _mlContext.Model.Save(_trainedModel, _trainingDataView.Schema, _modelPathRec);

            ///predict single issue
            FfmRecommendationData singleIssue = new FfmRecommendationData() { Application = "Close Loop", CauseCode = "Latency" };

            foreach (FfmRecommendationData issue in data)
            {
                singleIssue.ResolutionCode = issue.ResolutionCode;

                var prediction = _predictionEngineRec.Predict(singleIssue);

                if (!prediction.PredictedLabel)
                {
                    // Bring to a range from -1 (highly discouraged) to +1 (highly recommended).
                    prediction.Probability = -prediction.Probability;
                }

                Console.WriteLine($" {singleIssue.Application} {singleIssue.CauseCode} Result: Recommended: {singleIssue.ResolutionCode} { prediction.PredictedLabel} with proability {prediction.Probability} =============== ");
            }

            // Group prediction
            var testData = _mlContext.Data.ShuffleRows(_trainingDataView);

            var scoredData = _trainedModel.Transform(testData);
            var metrics = _mlContext.BinaryClassification.Evaluate(
                data: scoredData,
                labelColumnName: "Label",
                scoreColumnName: "Probability",
                predictedLabelColumnName: "PredictedLabel");

            Console.ReadKey();
        }

        public static void ProactiveIssueDetection()
        {
            _trainingDataView = _mlContext.Data.LoadFromTextFile<IssueOccurenceData>(path: _dataPathProac, hasHeader: true, separatorChar: ',');

            DetectSpike(_mlContext, _docsize, _trainingDataView);
        }

        static IDataView CreateEmptyDataView(MLContext mlContext)
        {
            // Create empty DataView. We just need the schema to call Fit() for the time series transforms
            IEnumerable<IssueOccurenceData> enumerableData = new List<IssueOccurenceData>();
            return mlContext.Data.LoadFromEnumerable(enumerableData);
        }

        static void DetectSpike(MLContext mlContext, int docSize, IDataView issueOccurence)
        {
            var iidSpikeEstimator = mlContext.Transforms.DetectIidSpike(outputColumnName: nameof(IssueOccurencePrediction.Prediction), inputColumnName: nameof(IssueOccurenceData.IssueOccurence), confidence: 95, pvalueHistoryLength: docSize / 4);

            ITransformer iidSpikeTransform = iidSpikeEstimator.Fit(CreateEmptyDataView(mlContext));

            IDataView transformedData = iidSpikeTransform.Transform(issueOccurence);

            var predictions = mlContext.Data.CreateEnumerable<IssueOccurencePrediction>(transformedData, reuseRowObject: false);

            Console.WriteLine("Alert\tScore\tP-Value");

            foreach (var p in predictions)
            {
                var results = $"{p.Prediction[0]}\t{p.Prediction[1]:f2}\t{p.Prediction[2]:F2}";

                if (p.Prediction[0] == 1)
                {
                    results += " <-- Spike detected";
                }

                Console.WriteLine(results);
            }
            Console.WriteLine("");
        }

        static void DetectChangepoint(MLContext mlContext, int docSize, IDataView issueOccurence)
        {
            var iidChangePointEstimator = mlContext.Transforms.DetectIidChangePoint(outputColumnName: nameof(IssueOccurencePrediction.Prediction), inputColumnName: nameof(IssueOccurenceData.IssueOccurence), confidence: 95, changeHistoryLength: docSize / 4);

            var iidChangePointTransform = iidChangePointEstimator.Fit(CreateEmptyDataView(mlContext));

            IDataView transformedData = iidChangePointTransform.Transform(issueOccurence);

            var predictions = mlContext.Data.CreateEnumerable<IssueOccurencePrediction>(transformedData, reuseRowObject: false);

            Console.WriteLine("Alert\tScore\tP-Value\tMartingale value");

            foreach (var p in predictions)
            {
                var results = $"{p.Prediction[0]}\t{p.Prediction[1]:f2}\t{p.Prediction[2]:F2}\t{p.Prediction[3]:F2}";

                if (p.Prediction[0] == 1)
                {
                    results += " <-- alert is on, predicted changepoint";
                }
                Console.WriteLine(results);
            }
            Console.WriteLine("");
        }
    }
}
