﻿using Microsoft.ML.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace KEDBTool.V1._0
{
    class IssueOccurenceData
    {
        [LoadColumn(0)]
        public string Time;

        [LoadColumn(1)]
        public float IssueOccurence;
    }
}
