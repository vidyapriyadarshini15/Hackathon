﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KEDBTool.V1._0
{
    class Centroid
    {
        public List<TextVector> GroupedText { get; set; }
    }
}
