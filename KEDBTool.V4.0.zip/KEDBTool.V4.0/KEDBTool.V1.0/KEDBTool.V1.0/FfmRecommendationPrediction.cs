﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KEDBTool.V1._0
{
    class FfmRecommendationPrediction
    {
        public bool PredictedLabel;

        public float Probability;

        public string Application;

        public string CauseCode;

        public string ResolutionCode;
    }
}
