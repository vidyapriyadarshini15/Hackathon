﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KEDBTool.V1._0
{
    class FfmRecommendationData
    {
        public bool Label;

        public string Application;

        public string CauseCode;

        public string ResolutionCode;
    }
}
